
import React from "react";

export default function EnglishTutorLanding() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-800">
      <header className="bg-white shadow">
        <div className="container mx-auto px-6 py-6 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Latifa English Tutor</h1>
            <p className="text-sm text-gray-600">From A1 → C1: grammar, vocabulary, writing, reading & speaking</p>
          </div>
          <div className="text-right">
            <p className="text-lg font-semibold">Price / Fiyat</p>
            <p className="text-xl text-green-600 font-bold">3000 TL / month · 3000 TL / ay</p>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-10 space-y-8">
        <section className="grid grid-cols-1 lg:grid-cols-2 gap-6 bg-white rounded-2xl shadow p-6">
          <div>
            <h2 className="text-2xl font-bold">About Me</h2>
            <p className="mt-3 text-gray-700">
              Hello! I’m <strong>Latifa Vanessa Karangwa</strong>, a certified English tutor with a <strong>TEFL</strong> (Teaching English as a Foreign Language) qualification and a passion for helping students communicate confidently and fluently.<br/><br/>
              I’ve taught English at <strong>Amerikan Life Language Institute</strong> in Düzce and <strong>English Time</strong> in Istanbul, designing interactive lessons that make learning both effective and enjoyable. My teaching covers all four language skills — speaking, writing, listening, and reading — with focus on grammar, vocabulary, and real-life communication.<br/><br/>
              I tailor each lesson to my students’ goals and level, ensuring steady progress from A1 to C1. For me, teaching is not just a profession but a joy. Watching my students grow and express themselves confidently in English is the most rewarding part of my work.
            </p>
          </div>
          <div>
            <h2 className="text-2xl font-bold">Hakkımda</h2>
            <p className="mt-3 text-gray-700">
              Merhaba! Ben <strong>Latifa Vanessa Karangwa</strong>, <strong>TEFL</strong> (Yabancı Dil Olarak İngilizce Öğretimi) sertifikasına sahip, öğrencilerin kendilerini güvenle ve akıcı bir şekilde ifade etmelerine yardımcı olmaktan büyük keyif alan bir İngilizce öğretmeniyim.<br/><br/>
              <strong>Düzce Amerikan Life Language Institute</strong> ve <strong>İstanbul English Time</strong> kurumlarında İngilizce öğrettim. Derslerimi etkili ve eğlenceli hale getirmek için etkileşimli yöntemler kullanıyorum. Eğitimim; konuşma, yazma, dinleme ve okuma becerilerini kapsar ve özellikle dilbilgisi, kelime bilgisi ve günlük iletişim becerilerine odaklanır.<br/><br/>
              Her öğrencinin hedeflerine ve seviyesine uygun, kişiselleştirilmiş bir öğretim planı hazırlıyorum. Benim için öğretmek sadece bir meslek değil, aynı zamanda büyük bir mutluluk kaynağıdır. Öğrencilerimin İngilizceyi özgüvenle kullanmaya başlaması, yaptığım işin en güzel ödülüdür.
            </p>
          </div>
        </section>
        {/* Additional sections like courses and materials can be added here */}
      </main>

      <footer className="bg-white border-t mt-8">
        <div className="container mx-auto px-6 py-6 text-sm text-gray-600 flex flex-col md:flex-row items-center justify-between">
          <div>© {new Date().getFullYear()} Latifa English Tutor — English tutoring (Kigali)</div>
          <div className="mt-3 md:mt-0">
            Email: <a href="mailto:latifakarangwa9@gmail.com" className="text-blue-600">latifakarangwa9@gmail.com</a> · WhatsApp: <a href="https://wa.me/905319498937" target="_blank" className="text-green-600">+90 531 949 8937</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
